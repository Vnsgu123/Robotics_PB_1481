<?php
// print_r($_POST);

// $qt=$_SESSION["qty"];

$id = $_POST["idd"];
$name = $_POST["titl"];
$price = $_POST["prc"];
// echo var_dump($name);

// $conn = mysqli_connect("localhost","root","","shop_db") or die("connection failed");

$conn = mysqli_connect("localhost","root","","testdb");

$query = " insert into cart values ('{$id}','{$name}','{$price}')";

if(mysqli_query($conn,$query))
{
    echo 1;
}
else
{
    echo 0;
}
?>