<?php
$eml = $_POST["email"];
$password = $_POST["pass"];
// print_r($_GET);
// print_r($_POST);

// echo var_dump($eml);

// print_r($_POST);

$conn = mysqli_connect("localhost","root","","testdb");

$query = "select * from users where email ='maitrey@123'";

$result = mysqli_query($conn,$query) ;

if($result)
{
    echo 1;
}
else
{
    echo 0;
}
?>      