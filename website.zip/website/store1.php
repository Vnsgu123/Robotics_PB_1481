<script type="text/javascript" src="jquery-3.7.1.min.js"></script>

<script type="text/javascript">

    $(document).ready(function(){
        $("#load").on("click",function(e){
            $.ajax({
                url:"insert.php",
                type:"POST",
                success:function(data){
                    // $('.output').text(JSON.stringify(data));

                    $("#tab1").html(data);
                }
            })
        })
    })


</script>
oninput="myipt(this.value)"

        <!-- <button type="button" class="b1" id="c1" onclick='datacart(<?= $product['id']?>,<?= $product['title'];?>,<?= $product['price'];?>)'>Add to Cart</button> -->
        <button type="button" class="b1" id="c1" onclick="funn('<?= $product['id'];?>','<?= $product['title'];?>','<?= $product['price'];?>','<script>$(".qty").val();</script>','<script>document.getElementById('').innerHTML;</script>')">Add to Cart</button>
        <tr class="tablerow">
				<td>Captcha Code: <span id="error-captcha" class="demo-error"><?php if(isset($error_message)) { echo $error_message; } ?></span>
					<input name="captcha_code" type="text"
					class="demo-input captcha-input">
				</td>
				<td><br /> <input type="submit" name="submit" value="Submit"
					class="demo-btn"></td>
			</tr>
		</table>
<?php if(isset($success_message)) { ?>
<div class="demo-success"><?php echo $success_message; ?></div>
<?php } ?>
</form>
</body>
</html>
