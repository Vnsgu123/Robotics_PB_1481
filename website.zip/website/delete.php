<?php

$id=$_POST["idda"];
// print_r($_GET);


$conn = mysqli_connect("localhost","root","","shop_db");

$query = "delete from users where ID = {$id}";
// $re = mysqli_query($conn,$query);

if(mysqli_query($conn,$query))
{
    echo 1;
}
else
{
    echo 0;
}



?>