<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table id="t1" >
    <tr>
        <td>
            <h1>Please enter your details</h1>
        </td>
    </tr>
    <tr>
        <td>
            ID:<input type="text" id="id"><br>
            name:<input type="text" id="name"><br>
            email:<input type="text" id="email"><br>
            password:<input type="password" id="pass"><br>
            user_type:<input type="text" id="user"><br>
            <div class="row">
        <div class="form-group col-6">
          <label>Enter Captcha</label>
          <input type="text" class="form-control" name="captcha" id="captcha">
        </div>

            <div class="form-group col-6">
            <label>Captcha Code</label>
            <img src=captcha.php" alt="PHP Captcha">
        </div>



            <input type="submit" id="load" value="save">
        </td>
    </tr>
    <tr>
        <td id="tab1">
        </td>
    </tr>
    </table>    

    <div class="output"></div>

<script type="text/javascript" src="jquery-3.7.1.min.js"></script>

<script type="text/javascript">

    $(document).ready(function(){
        $("#load").on("click",function(e){
            e.preventDefault();
            var idd =$("#id").val();
            var fname =$("#name").val();
            var email =$("#email").val();
            var password =$("#pass").val();
            var userr =$("#user").val();


            $.ajax({
                url:"loaddata.php",
                type:"POST",
                data:{first_name:fname,id:idd,emaill:email,pass:password,user:userr},
                success:function(data){

                    if(data==1)
                    {
                        window.location.href = "login.php";
                        
                    }
                    else
                    {
                        alert("cant sav data");
                    }
                }
                
            })
        })
        // $(document).on("click",".btn-del",function submitData(action){
            // function submitData(action){
            //     // var actionn = action;
            //     alert("gdhgdgga");
            //     var element=this;
            //     $.ajax({
            //     url :"delete.php",
            //     type:"POST",
            //     data:{idda:action},
            //     success:function(data){
            //         if(data==1)
            //         {
            //             $(element).closest("tr").fadeOut();
            //         }else{
            //             alert('not   not');
            //         }
            //     }
            // })

            // }
        // })
        
            
            

        // $(document).on("click",".btn-del",function(){
        //     // var idaa = $(this).data("ID");
        //     var idaa = action ;
        //     alert(idaa); 
        //     // var idaa = 25;

            // var element=this;
            // $.ajax({
            //     url :"delete.php",
            //     type:"POST",
            //     data:{idda:idaa},
            //     success:function(data){
            //         if(data==1)
            //         {
            //             $(element).closest("tr").fadeOut();
            //         }else{
            //             $(element).closest("tr").fadeOut();
            //         }
            //     }
            // })
        // })

        })

        // function submitData(action){
        //     $(document).ready(function(){
        //         // var actionn = action;
        //         alert(action);
        //         var element=this;
        //         $.ajax({
        //         url :"delete.php",
        //         type:"POST",
        //         data:{idda:action},
        //         success:function(data){
        //             if(data==1)
        //             {
        //                 $(element).closest("tr").fadeOut();
        //             }else{
        //                 alert('not   not');
        //             }
        //         }
        //     })

        //     })
        // }
    


</script>


</body>
</html>