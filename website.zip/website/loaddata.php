<?php

$id = $_POST["id"];
$name = $_POST["first_name"];
$email = $_POST["emaill"];
$password = $_POST["pass"];
$userss = $_POST["user"];


// $conn = mysqli_connect("localhost","root","","shop_db") or die("connection failed");

$conn = mysqli_connect("localhost","root","","testdb");
// $query = " insert into users values ('{$id}','{$name}','{$email}','{$password}','{$userss}')";

$query = " insert into users values ('{$email}','{$password}')";

if(mysqli_query($conn,$query))
{
    echo 1;
}
else
{
    echo 0;
}
?>