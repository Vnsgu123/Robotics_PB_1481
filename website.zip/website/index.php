<?php
session_start();

$conn=mysqli_connect('localhost','root','','testdb');

$sql = "select * from products where featured = 1";

$result = mysqli_query($conn , $sql)


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <script src="jquery-3.7.1.min.js"></script>
    <link rel="js/bootstrap.min.js"/>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>shopping-website</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">TechBuy.com</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="viewcart.php">View Cart</a>
        </li>      
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="login.php">LOGIN</a>
        </li>
<select name="type" id="list">
  <option value="index.php">Mobile phones</option>
  <option value="saab.php">Laptop</option>
</select>
<input type=button value="Go" onclick="goToNewPage()" />
<script type="text/javascript">
    function goToNewPage()
    {
        var url = document.getElementById('list').value;
        if(url != 'none') {
            window.location = url;
        }
    }
</script>

    </div>
  </div>
</nav>
<div class="class-mod-2"></div>
    <div class="class-mod-8">
    <div class="row" style="margin:14px ">
    <h2 class="text-center" >-----------------------------------------------------Top Products-------------------------------------------------------</h2><br><br>
    <?php 
    while($product=mysqli_fetch_assoc($result)):
    
    ?> 
    <div class="col_mod-7" >
        <h3 class="e1"> <?= $product['title'];?></h3>
        <img  id="e2" src="<?= $product['image'];?>" alt="<?=     $product['title'];?>" />
        <p class="lp" id="e3">Rs <?= $product['price'];?></p>
        <input type="number" id="qty" > <br>
        <!-- <script>var ele = this</script> -->

        <!-- <script>$(".qty").val();</script> -->
        <!-- <a href="cart.php"> -->
        <button type="button" class="b1" id="c1" onclick="funn('<?= $product['id'];?>','<?= $product['title'];?>','<?= $product['price'];?>')">Add to Cart</button>
        <!-- </a> -->
    </div>
    <?php endwhile;  ?>


</div>

</div>
<script>
  // function myipt(action)
  // {
  //   alert(action);
  //   var w =action;


  // }
  function funn(id,action,price){


        $(document).ready(function(){
      

          alert(action);

          // qtyy=qty.value;

          // $(".b1").on("click",function(e){

          // var name = $(this).html();
          // alert(name);

    //     // var actionn = action;
    //     alert(action);
    //     // var element=actio;
        $.ajax({
        url :"cart.php",
        type:"POST",
        data:{idd:id,titl:action,prc:price},
        success:function(data){
            if(data==1)
            {
              alert("product added successfully");
            }else{
                alert("not   not");

            }
        }
    })

    })
    
  }
  
</script>
</body>
</html>