CREATE TABLE `testdb`.`products` (`id` INT NOT NULL , `title` VARCHAR(25) NOT NULL , `price` INT NOT NULL , `brand` VARCHAR(20) NOT NULL , `image` VARCHAR(200) NOT NULL , `discription` VARCHAR(200) NOT NULL , `featured` INT NOT NULL ) ENGINE = InnoDB;


INSERT INTO `products` (`id`, `title`, `price`, `brand`, `image`, `discription`, `featured`) VALUES ('1', 'Google pixel 3a', '20000', 'Google', 'C:\\xampp\\htdocs\\website\\google_pixel_3a_xl-2.jpg', 'newly launched', '1');



<img src="<?php $product['image'];?>" alt="<?php $product['title'];?>" />
        <p class="lp">Rs <?php $product['price'];?></p>


        {
    print_r($product);
    };
    
    <!-- <? php endwhile;  ?> -->
