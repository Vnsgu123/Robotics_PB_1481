
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="CSS/style.css">

</head>
<body>

<?php
// if(isset($message)){
//    foreach($message as $message){
//       echo '
//       <div class="message">
//          <span>'.$message.'</span>
//          <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
//       </div>
//       ';
//    }
// }
// ?>
   
<div class="form-container">

   <form action="" method="post">
      <h3>login now</h3>
      <input type="email" id="email" placeholder="enter your email" required class="box">
      <input type="password" id="password" placeholder="enter your password" required class="box">
      <input type="submit" id="submitt" value="login now" class="btn" >
      <p>don't have an account? <a href="register.php">register now</a></p>
   </form>

</div>
<script type="text/javascript" src="jquery-3.7.1.min.js"></script>

<script type="text/javascript">

         $(document).ready(function(){
            alert("ksksksk")

            $("#submitt").on("click",function(e){
               var e1=$("#email").val();
               var e2=$("#password").val();
               alert('inside222');

      $.ajax({
         url:"loginajazx.php",
         type:"POST",
         data:{email:e1,pass:e2},
         success:function(data){
            if(data==1)
            {
               window.location.href = "index.php";
            }
            else{
               alert('not correct');
            }
         }

            })
         })
      })         


   // if(isset($_POST['submit'])){
   //    function funn(){
   //       alert('inside');
   //         $(document).ready(function(){
   //          $("#load").on("click",function(e){


   //          alert('inside000');

   //    var e1=$("#email").val();
   //    var e2=$("#password").val();
   //    alert('inside222');

   //    $.ajax({
   //       url:"loginajax.php",
   //       type:"POST",
   //       data:{email:e1,pass:e2},
   //       success:function(data){
   //          if(data==1)
   //          {
   //             header('location:index.php');
   //          }
   //          else{
   //             alert('not correct');
   //          }
   //       }
   //    })



   // })
   // }
</script>
</body>
</html>