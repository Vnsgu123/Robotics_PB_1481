<?php

$id=$_POST["idda"];
// print_r($_GET);


$conn = mysqli_connect("localhost","root","","testdb");

$query = "delete from cart where id = {$id}";
// $re = mysqli_query($conn,$query);

if(mysqli_query($conn,$query))
{
    echo 1;
}
else
{
    echo 0;
}



?>