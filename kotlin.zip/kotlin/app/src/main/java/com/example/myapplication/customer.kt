package com.example.myapplication

data class customer(var id:Int,var name:String,var acc_no:String) {
}