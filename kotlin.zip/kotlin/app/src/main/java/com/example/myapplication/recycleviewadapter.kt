package com.example.myapplication

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class recycleviewadapter: RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    class ViewHolder(custview:View):RecyclerView.ViewHolder(custview)
    {
        val txtid:TextView = custview.findViewById(R.id.)


    }
}